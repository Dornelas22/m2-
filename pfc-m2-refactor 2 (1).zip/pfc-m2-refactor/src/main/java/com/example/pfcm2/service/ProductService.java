
package com.example.pfcm2.service;

import com.example.pfcm2.dto.ProductDTO;
import com.example.pfcm2.model.Product;
import com.example.pfcm2.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    private ProductDTO toDTO(Product p) {
        return new ProductDTO(p.getId(), p.getName(), p.getPrice());
    }

    private Product toEntity(ProductDTO dto) {
        Product p = new Product();
        p.setName(dto.getName());
        p.setPrice(dto.getPrice());
        return p;
    }

    public List<ProductDTO> findAll() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Optional<ProductDTO> findById(Long id) {
        return repository.findById(id).map(this::toDTO);
    }

    public ProductDTO create(ProductDTO dto) {
        Product p = toEntity(dto);
        Product saved = repository.save(p);
        return toDTO(saved);
    }

    public Optional<ProductDTO> update(Long id, ProductDTO dto) {
        return repository.findById(id).map(existing -> {
            existing.setName(dto.getName());
            existing.setPrice(dto.getPrice());
            Product updated = repository.save(existing);
            return toDTO(updated);
        });
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
