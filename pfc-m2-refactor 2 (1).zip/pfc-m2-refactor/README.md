
# PFC-M2-Refactor (exemplo para atividade M2)

Projeto mínimo pronto para Aplicativos Web (M2). Serve como base para aplicar **Clean Code** e criar a branch com a data 10-11.

## O que tem
- Java 17 + Spring Boot
- CRUD de Product (Controller, Service, Repository, DTO, Entity)
- H2 in-memory database (não precisa configurar banco externo)
- Endpoints:
  - GET /api/products
  - GET /api/products/{id}
  - POST /api/products
  - PUT /api/products/{id}
  - DELETE /api/products/{id}

## Como rodar
1. Ter Java 17+ e Maven instalados.
2. `mvn spring-boot:run` na raiz do projeto.
3. Acesse `http://localhost:8080/api/products`

## Observações para entrega da M2
- Crie no GitHub um repositório e suba este projeto.
- Crie uma branch com o nome `refactor-10-11` e faça as alterações de Clean Code nesta branch.
- Adicione o professor Leonardo como colaborador no GitHub para que ele possa avaliar.

